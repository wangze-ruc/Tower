#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QPainter>     //画家
#include <QMouseEvent>  //鼠标事件
#include <Qtimer>       //定时器
#include <QLabel>

class MainWindow : public QWidget
{
//    Q_OBJECT
private:


    void paintEvent(QPaintEvent *);         //绘图事件
//    void mouseMoveEvent(QMouseEvent *);   //鼠标移动事件

    void DrawMapArr(QPainter&);             //用于画出地图函数






    const int LevelNumber;      //标识关卡

    bool DisplayAllRange = false;  //标识是否显示所有防御塔的攻击范围

public:
    MainWindow(int);            //构造
    ~MainWindow();
};

#endif  //MAINWINDOW_H
